package br.edu.ifgoiano.servico;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.ifgoiano.entidade.Livro;
import br.edu.ifgoiano.repository.LivroRepository;

@Service
public class LivroServiceImpl implements LivroService{
	@Autowired
	private LivroRepository livroRepository;
	
	
	
	

	@Override
	public List<Livro> listarLivros() {
		// TODO Auto-generated method stub
		return livroRepository.findAll();
	}
}
