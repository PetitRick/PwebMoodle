package br.edu.ifgoiano.servico;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.ifgoiano.entidade.Livro;
import br.edu.ifgoiano.repository.LivroRepository;

@Service
public class LivroServiceImpl implements LivroService{
	@Autowired
	private LivroRepository livroRepository;
	
	@Override
	public List<Livro> listarLivros() {
		// TODO Auto-generated method stub
		return livroRepository.findAll();
	}

	@Override
	public void inserir(Livro livro) {
		this.livroRepository.save(livro);	
	}
	
	@Override
	public Livro obterLivro(Long id) {
		return this.livroRepository.getReferenceById(id);
	}

	@Override
	public void alterarLivro(Livro livro) {
		// TODO Auto-generated method stub
		this.livroRepository.save(livro);
	}
	


}
